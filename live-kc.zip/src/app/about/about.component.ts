import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kc-about',
  template: `
    <p>
      about works!
    </p>
  `,
  styles: []
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
