import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kc-referencias',
  templateUrl: './referencias.component.html',
  styleUrls: ['./referencias.component.css']
})
export class ReferenciasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
