export interface Grupo {
    id: number;
    nombre: string;
    descripción: string;
}
