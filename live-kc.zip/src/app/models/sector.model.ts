export interface Sector {
    id: number;
    nombre: string;
    descripción: string;
}
