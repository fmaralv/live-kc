export interface Aficion {
    id: number;
    nombre: string;
    descripción: string;
}
