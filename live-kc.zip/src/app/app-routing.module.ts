import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'tareas',loadChildren: () => import('src/app/tareas/tareas.module').then(m => m.TareasModule)},
  { path: 'libros',loadChildren: () => import('src/app/libros/libros.module').then(m => m.LibrosModule)},
  { path: 'contactos',loadChildren: () => import('src/app/contactos/contactos.module').then(m => m.ContactosModule)},
  { path: '', pathMatch: 'full', redirectTo: 'home' },
  { path: '**', pathMatch: 'full', redirectTo: 'home' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
