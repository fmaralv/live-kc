import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kc-contactos',
  template: `
    <div class="row">
      <kc-form-vd class="col"></kc-form-vd>
    </div>
  `,
  styles: []
})
export class ContactosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
